# Easy-use

Those scripts are mainly intended for non-developer users. It eases the process of running a basic configuration for your machine and allowing you to quickly work with GitHub.

Test
