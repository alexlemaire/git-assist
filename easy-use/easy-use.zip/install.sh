#!/bin/bash

konsole --noclose -e ./scripts/install.sh
